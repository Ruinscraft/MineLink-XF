<?php

namespace Ruinscraft\MCLink\Api\Controller;

use XF\Mvc\Entity\Entity;
use XF\Mvc\ParameterBag;

class Code extends \XF\Api\Controller\AbstractController {

    public function actionGet(ParameterBag $params) {
        $code = $params->code;
        $codeRepo = $this->getCodeRepo();
        $codeEntity = $codeRepo->fetchCode($code);

        $result = [];

        if (!$codeEntity) {
            return $this->apiResult($result);
        }

		$result = [
			'code' => $codeEntity->toApiResult(Entity::VERBOSITY_VERBOSE)
		];

        return $this->apiResult($result);
    }

    public function actionPut(ParameterBag $params) {
        return $this->apiSuccess();
    }

    protected function getCodeRepo() {
		return $this->repository('Ruinscraft\MCLink:Code');
	}

}

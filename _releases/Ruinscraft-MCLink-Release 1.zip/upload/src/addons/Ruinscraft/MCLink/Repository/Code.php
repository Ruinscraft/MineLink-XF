<?php

namespace Ruinscraft\MCLink\Repository;

use XF\Mvc\Entity\AbstractCollection;
use XF\Mvc\Entity\Repository;

class Code extends Repository {

    public function fetchCode($code) {
		return $this->finder('Ruinscraft\MCLink:Code')
			->where('code', $code)
			->fetchOne();
	}

}

<?php

namespace Ruinscraft\MCLink\Entity;

use XF\Mvc\Entity\Structure;

class Code extends \XF\Mvc\Entity\Entity {

	public static function getStructure(Structure $structure) {
		$structure->table = 'mclink_codes';
		$structure->shortName = 'Ruinscraft\MCLink:Code';
		$structure->primaryKey = 'code';
		$structure->columns = [
			'code' =>   				['type' => self::STR, 'required' => true],
			'created_at' =>		    	['type' => self::UINT, 'required' => true],
			'used' =>		        	['type' => self::UINT, 'required' => true],
			'user_id' =>				['type' => self::UNIT, 'required' => false]
		];

		return $structure;
	}

	protected function setupApiResultData(
		\XF\Api\Result\EntityResult $result, $verbosity = self::VERBOSITY_NORMAL, array $options = []
	) {
		$result->code = $this->code;
		$result->created_at = $this->created_at;
		$result->used = $this->used;
	}

}

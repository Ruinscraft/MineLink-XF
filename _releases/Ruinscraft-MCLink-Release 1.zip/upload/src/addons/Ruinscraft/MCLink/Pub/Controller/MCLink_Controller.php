<?php

namespace Ruinscraft\MCLink\Pub\Controller;

class MCLink_Controller extends \XF\Pub\Controller\AbstractController {

    public function actionIndex() {
        $userId = \XF::visitor()->user_id;

        /* Ensure a user is logged in */
        if (!$userId) {
			return $this->message(\XF::phrase('mclink_must_be_logged_in'));
        }
        
        $code = $_GET['code'];

        // Check code is at least the right length before hitting the database
        // Codes are UUID v4 without -
        // Example: ea6d8c59cee8408490c92c210714e9be
        if (strlen($code) !== 32) {
            return $this->message(\XF::phrase('mclink_invalid_code'));
        }

        $codeRepo = $this->getCodeRepo();
        $codeEntity = $codeRepo->fetchCode($code);

        if (!$codeEntity) {
            return $this->message(\XF::phrase('mclink_invalid_code'));
        }

        if ($codeEntity->used) {
            return $this->message(\XF::phrase('mclink_invalid_code'));
        }

        $codeTime = $codeEntity->created_at;
        $nowMillis = round(microtime(true) * 1000);

        if (($codeTime + 300000) < $nowMillis) {
            return $this->message(\XF::phrase('mclink_invalid_code'));
        }

        $codeEntity->fastUpdate('used', true);
        $codeEntity->fastUpdate('user_id', $userId);

        return $this->message(\XF::phrase('mclink_link_success'));

        // $viewParams = array(
        //     'code' => $codeEntity->created_at,
        //     'user_id' => $codeEntity->created_at
        // );

        // return $this->view('Ruinscraft\MCLink:View', 'mclink_link', $viewParams);
    }

    protected function getCodeRepo() {
		return $this->repository('Ruinscraft\MCLink:Code');
	}

}
